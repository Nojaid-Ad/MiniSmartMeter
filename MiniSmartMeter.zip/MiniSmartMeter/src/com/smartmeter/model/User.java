package com.smartmeter.model;

import java.sql.Timestamp;

public class User {

    private int id;
    private String username;
    private String password;
    private double balance;
    private Timestamp createdAt;

    public User(String username, String password, double balance) {
        this.username = username;
        this.password = password;
        this.balance = balance;
    }

    public User(int id, String username, String password, double balance, Timestamp createdAt) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    @Override
    public String toString() {
        return "User{"
                + "id=" + id
                + ", username='" + username + '\''
                + ", balance=" + balance
                + ", createdAt=" + createdAt
                + '}';
    }
}
