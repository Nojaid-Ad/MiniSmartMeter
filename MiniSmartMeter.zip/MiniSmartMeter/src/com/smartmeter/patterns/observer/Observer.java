package com.smartmeter.patterns.observer;

public interface Observer {
    void update(String message, Integer userId);
}
